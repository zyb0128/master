# hongbao
根据微信高级红包接口，开发PHP版本的API接口。
[分析代码](http://www.jyboke.com/2015/02/25/php-wechat-hongbao-api/)
